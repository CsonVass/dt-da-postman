## Sources
* [Postman CLI vs Newman](https://blog.postman.com/postman-cli-vs-newman/)
* [Postman Test Scripts](https://learning.postman.com/docs/writing-scripts/test-scripts/)
* [Download Postman CLI](https://learning.postman.com/docs/postman-cli/postman-cli-installation/#windows-installation)
* [Postman CLI Config](https://learning.postman.com/docs/postman-cli/postman-cli-run-collection/)
* [Postman Mock Server](https://learning.postman.com/docs/designing-and-developing-your-api/mocking-data/setting-up-mock/)
* [Install and run Newman](https://learning.postman.com/docs/collections/using-newman-cli/installing-running-newman/)
* [Variables](https://learning.postman.com/docs/sending-requests/variables/)
* [ChatGPT](https://chat.openai.com/)