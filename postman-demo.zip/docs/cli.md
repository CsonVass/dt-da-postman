## CLI

### Postman CLI

```bash
postman login --with-api-key <generated-api-key>
```

```bash
postman collection run <collection-id>
```
OR
```bash
postman collection run <exported json>
```

### Newman
```bash
newman run <exported json>
```