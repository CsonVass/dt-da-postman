> Welcome to the documentation of the interactive demonstration on Postman presented to the DevOps Academy on June 5, 2023. Here, you'll find comprehensive information about the showcased features and functionalities. 

## Content
* [Setup](docs/setup.md)
* [About Postman](docs/about-postman.md)
* [Testing API](docs/testing-api.md)
* [CLI](docs/cli.md)
* [Sources](docs/sources.md)

